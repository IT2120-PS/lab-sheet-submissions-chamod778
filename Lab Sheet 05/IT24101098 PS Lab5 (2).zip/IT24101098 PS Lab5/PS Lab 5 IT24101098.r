setwd("C:\\Users\\IT24101098\\Desktop\\IT24101098 PS Lab5")
getwd()
Delivery_Times <- read.table("Exercise – Lab 05.txt", header = TRUE, sep = ",")
fix(Delivery_Times)

hist(Delivery_Times$DeliveryTime, 
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Frequency",
     breaks = seq(20, 70, length = 10),  # 9 intervals → 10 break points
     right = FALSE,
     col = "skyblue",
     border = "black")

hist_data <- hist(Delivery_Times$DeliveryTime, 
                  breaks = seq(20, 70, length = 10), 
                  right = FALSE, 
                  plot = FALSE)

cum_freq <- cumsum(hist_data$counts)
breaks <- hist_data$breaks

# Add a starting point at 20 with cumulative frequency 0
cum_breaks <- c(breaks[1], breaks[-1])
cum_freq <- c(0, cum_freq)

# Draw ogive (cumulative frequency polygon)
plot(cum_breaks, cum_freq, type = 'l',
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "blue", lwd = 2)
points(cum_breaks, cum_freq, pch = 19, col = "red")